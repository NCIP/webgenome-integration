package gov.nih.nci.cg.findings.handlers;

import gov.nih.nci.cg.findings.SpecimenBasedMolecularFinding;
import gov.nih.nci.cg.criteria.SpecimenBasedFindingSearchCriteria;
import gov.nih.nci.cg.criteria.StudyParticipantCriteria;
import gov.nih.nci.cg.criteria.SpecimenCriteria;
import gov.nih.nci.cg.criteria.PatientCriteria;
import gov.nih.nci.cg.enums.OperatorType;
import gov.nih.nci.cg.util.HibernateUtil;

import java.util.*;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.Query;

/**
 * User: Ram Bhattaru <BR>
 * Date: Mar 19, 2006 <BR>
 * Version: 1.0 <BR>
 *
 * This class uses Template pattern in combination with Strategy pattern.  This class
 * is primarily responsible for all types of findings hence acts as a Controller to
 * persistence layer
 */
public abstract class SpecimenFindingHandler {
   protected abstract StringBuffer handle(SpecimenBasedFindingSearchCriteria sc,
                                                 HashMap params, Session session);
   protected abstract Class getFindingType();
   public abstract void initializeProxies(Collection<? extends SpecimenBasedMolecularFinding> findings);
    /**
     * This method calls handle() method on the correponding subclass in which this code
     * is exucuting.  This method adds required criteria to Hibernate Criteria object (that
     * includes handling of both AnnotationCriteria and Findings object criteria itself)
     * It then instantiates a StudyBasedCriteria handler (based on instance of StudyBasedCriteria
     * and delegates appending StudyBasedCriteria to the above criteria and there after
     * executing the whole query.
     * @param sc This represents one subtype of SpecimenBasedFindingSearchCriteria
     * @return Collection of one of sub types of SpecimenBasedMolecularFinding corresponding to the
     *          SpecimenBasedFindingSearchCriteria passed in.
     */

    public Collection<? extends SpecimenBasedMolecularFinding> getFindings(SpecimenBasedFindingSearchCriteria sc) {
        Collection findings = null;
        Set<? extends SpecimenBasedMolecularFinding> results = new HashSet();
        StudyParticipantCriteria studyCrit = sc.getStudyParticipantCriteria();
        OperatorType opType = sc.getStudyParticipantCriteriaOpType();
        if (opType == null) opType = OperatorType.AND; // default to AND

        Session session = HibernateUtil.getSession();
        HibernateUtil.beginTransaction();

        HashMap params = new HashMap();
        StringBuffer hSQL = handle(sc, params, session);



        if (studyCrit == null) {
            if (params.isEmpty()) {
                // means Annotation criteria did not pass
                session.close();
                return results;
            }
            Query q = session.createQuery(hSQL.toString());
            setParamsOnQuery(params, q);
            Collection objs = q.list();
            initializeProxies(objs);
            results.addAll(objs);
            session.close();
            return results;
        }

        // means include StudyParticipant criteria
        StudyParticipantHandler handler = null;
        if (studyCrit instanceof SpecimenCriteria )  {
            handler = new StudyParticipantHandler.SpecimenHandler();
        } else if (studyCrit instanceof PatientCriteria) {
            handler = new StudyParticipantHandler.PatientHandler();
        }

        findings = handler.searchFindings(studyCrit, opType, getFindingType(), hSQL, params, session);
        initializeProxies(findings);
        results.addAll(findings);
        session.close();
        return results;
     }

    public static void setParamsOnQuery(HashMap params, Query q) {
        Set paramKeys = params.keySet();
        Iterator iter = paramKeys.iterator();
        while (iter.hasNext()) {
            String key = (String)iter.next();
            Object value =  params.get(key);
            Class c = value.getClass();

            if (value instanceof List)
                q.setParameterList(key, (ArrayList)value);
            else if (value instanceof Set)
                q.setParameterList(key, (HashSet) value);

            else q.setParameter(key, value);

        }
    }
}
