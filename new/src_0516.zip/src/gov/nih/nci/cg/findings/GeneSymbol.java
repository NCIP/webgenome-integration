package gov.nih.nci.cg.findings;

/**
 * User: Ram Bhattaru <BR>
 * Date: Apr 4, 2006 <BR>
 * Version: 1.0 <BR>
 */
public class GeneSymbol extends GeneIdentifier{
    public GeneSymbol(String value) {
        super(value);
    }

    public GeneSymbol() {
    }

}
