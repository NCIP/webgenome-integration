package gov.nih.nci.cg.findings;

import java.util.Enumeration;

/**
 * User: Ram Bhattaru <BR>
 * Date: Mar 19, 2006 <BR>
 * Version: 1.0 <BR>
 */

public class GeneIdentifier {
	public final static String VALUE = "value";
    private String value;

    public GeneIdentifier() {
    }

    public GeneIdentifier(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        final GeneIdentifier that = (GeneIdentifier) o;

        if (value != null ? !value.equals(that.value) : that.value != null) return false;

        return true;
    }

    public int hashCode() {
        return (value != null ? value.hashCode() : 0);
    }
};

