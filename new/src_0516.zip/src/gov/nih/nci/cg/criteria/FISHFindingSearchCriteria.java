package gov.nih.nci.cg.criteria;

import gov.nih.nci.cg.findings.CopyNumberAbnomalityStatus;
import gov.nih.nci.cg.findings.handlers.SpecimenFindingHandler;
import gov.nih.nci.cg.findings.handlers.FISHFindingHandler;
import gov.nih.nci.cg.enums.OperatorType;

/**
 * User: Ram Bhattaru <BR>
 * Date: Apr 4, 2006 <BR>
 * Version: 1.0 <BR>
 */

public class FISHFindingSearchCriteria extends SpecimenBasedFindingSearchCriteria {
    private GeneBiomarkerSearchCriteria bioMarkerCrit;
    private CopyNumberAbnomalityStatus cnaStatus;
    private String reference;
    private RatioValueCriteria ratioValueCrit;
    private RatioRangeValueCriteria ratioRangeValueCrit;
    private RatioCriteria ratioCrit;


/*
    public RatioValueCriteria getRatioValueCrit() {
        return ratioValueCrit;
    }

    public void setRatioValueCrit(RatioValueCriteria ratioValueCrit) {
        this.ratioValueCrit = ratioValueCrit;
    }

    public RatioRangeValueCriteria getRatioRangeValueCrit() {
        return ratioRangeValueCrit;
    }

    public void setRatioRangeValueCrit(RatioRangeValueCriteria ratioRangeValueCrit) {
        this.ratioRangeValueCrit = ratioRangeValueCrit;
    }
*/

    public FISHFindingSearchCriteria(){

    }

    public GeneBiomarkerSearchCriteria getBioMarkerCrit() {
        return bioMarkerCrit;
    }

    /**
     *
     * @param bioMarkerCrit
     */
    public void setBioMarkerCrit(GeneBiomarkerSearchCriteria bioMarkerCrit) {
        this.bioMarkerCrit = bioMarkerCrit;
    }

    /**
     *
     * @param cnaStatus
     */
    public void setCNASatus(CopyNumberAbnomalityStatus cnaStatus){
        this.cnaStatus = cnaStatus;
    }


    /**
     *
     * @param ratio
     * @param ratioOperator will be one of OperatorType.GT/OperatorType.LT/OperatorType.EQ
     */
    public void setRatio(Double ratio, OperatorType ratioOperator) {
        if ((ratioOperator != OperatorType.GT) && (ratioOperator != OperatorType.LT) &&
            (ratioOperator != OperatorType.EQ) )
           throw new RuntimeException("Invalid OperatorType.  It should be one of GT/LT/EQ only");
        ratioValueCrit = new RatioValueCriteria();
        ratioValueCrit.setRatio(ratio);
        ratioValueCrit.setRatioOperator(ratioOperator);

        ratioCrit =  ratioValueCrit;
    }

    /**
     *
     * @param ratioUpperLimit
     * @param ratioLowerLimit
     */
    public void setRatioRange(Double ratioUpperLimit, Double ratioLowerLimit ){
        Double newLower = null;
        Double newUpper = null;
        if (ratioLowerLimit > ratioUpperLimit ) {
            //swap
            newLower = new Double(ratioUpperLimit.doubleValue());
            newUpper = new Double(ratioLowerLimit.doubleValue());
        }
        else {
            newLower = new Double(ratioLowerLimit.doubleValue());
            newUpper = new Double(ratioUpperLimit.doubleValue());
        }

        ratioRangeValueCrit = new RatioRangeValueCriteria();
        ratioRangeValueCrit.setRatioUpperLimit(newUpper);
        ratioRangeValueCrit.setRationLowerLimit(newLower);

        ratioCrit = ratioRangeValueCrit;
    }

    /**
     *
     * @param referenceName
     */
    public void setReference(String referenceName){
        this.reference = referenceName;
    }


    public CopyNumberAbnomalityStatus getCnaStatus() {
          return cnaStatus;
    }

    public String getReference() {
          return reference;
    }


    public RatioCriteria getRatioCrit() {
        return ratioCrit;
    }



    public class RatioRangeValueCriteria implements RatioCriteria {
        private Double ratioUpperLimit;
        private Double rationLowerLimit;

        public Double getRatioUpperLimit() {
            return ratioUpperLimit;
        }

        public void setRatioUpperLimit(Double ratioUpperLimit) {
            this.ratioUpperLimit = ratioUpperLimit;
        }

        public Double getRatioLowerLimit() {
            return rationLowerLimit;
        }

        public void setRationLowerLimit(Double rationLowerLimit) {
            this.rationLowerLimit = rationLowerLimit;
        }
    }
    public class RatioValueCriteria implements RatioCriteria {
        private Double ratio;
        private OperatorType ratioOperator;

        public OperatorType getRatioOperator() {
            return ratioOperator;
        }

        public void setRatioOperator(OperatorType ratioOperator) {
            this.ratioOperator = ratioOperator;
        }

        public Double getRatio() {
            return ratio;
        }

        public void setRatio(Double ratio) {
            this.ratio = ratio;
        }
    }
    public interface RatioCriteria { // marker interface
    }
    public SpecimenFindingHandler getHandler() {
        return new FISHFindingHandler();
    }

}
