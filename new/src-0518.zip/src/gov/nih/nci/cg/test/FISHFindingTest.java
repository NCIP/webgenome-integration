package gov.nih.nci.cg.test;

import junit.framework.TestCase;
import junit.framework.Test;
import junit.framework.TestSuite;
import gov.nih.nci.cg.criteria.*;
import gov.nih.nci.cg.findings.*;
import gov.nih.nci.cg.enums.OperatorType;

import java.util.Collection;
import java.util.ArrayList;
import java.util.Iterator;

/**
 * User: Ram Bhattaru <BR>
 * Date: Apr 4, 2006 <BR>
 * Version: 1.0 <BR>
 */
public class FISHFindingTest extends TestCase {
    FISHFindingSearchCriteria  fishSC;
    protected void setUp() throws Exception {
        fishSC = new FISHFindingSearchCriteria();
    }

    private void setGeneBiomarkerSearchCriteria() {
        GeneSymbol gs1 = new GeneSymbol();
        gs1.setValue("TOP2A");
        GeneSymbol gs2 = new GeneSymbol();
        gs2.setValue("ERBB2");

        Collection<GeneSymbol> geneSymbols = new ArrayList<GeneSymbol>();
        geneSymbols.add(gs1);
        //geneSymbols.add(gs2);

        GeneBiomarkerSearchCriteria bsc = new GeneBiomarkerSearchCriteria();
        bsc.setGeneSymbols(geneSymbols);

        fishSC.setBioMarkerCrit(bsc);
    }
    private void setCNAStatus() {
        CopyNumberAbnomalityStatus status = CopyNumberAbnomalityStatus.AMPLIFIED;
        fishSC.setCNASatus(status);
    }
    private void setReferenceName() {
        fishSC.setReference("CEP17");
    }
    private void setRaioCrit() {
        //fishSC.setRatio(8.0, OperatorType.LT);
        //fishSC.setRatio(8.0, OperatorType.GT);
        fishSC.setRatioRange(6.0, 8.0);
    }
    public void testFISHFindingCrit(){
        setGeneBiomarkerSearchCriteria();
        //setCNAStatus();
        //setReferenceName();
        setRaioCrit();
        setSpecimenCriteria();
        executeSearch();
    }
    private void setParticipantCriteria() {
        PatientCriteria sp = new PatientCriteria();
        Collection<String> studyIdentifiers = new ArrayList<String>();
        studyIdentifiers.add("1036");
        sp.setStudySubjectIdentifiers(studyIdentifiers);

        Collection<TimeCourse> timeCourses = new ArrayList<TimeCourse>();
        //timeCourses.add(TimeCourse.T1);
       //timeCourses.add(TimeCourse.T2);
       // timeCourses.add(TimeCourse.T3);
        //timeCourses.add(TimeCourse.T4);
       // sp.setTimeCourse(timeCourses);

        fishSC.setStudyParticipantCriteria(sp);
        fishSC.setStudyParticipantCriteriaOpType(OperatorType.AND);
    }
    private void setSpecimenCriteria() {
        SpecimenCriteria sc = new SpecimenCriteria();
        Collection<String>specimenIDs = new ArrayList<String>();
        specimenIDs.add("215148");
        sc.setSpecimenIDs(specimenIDs);
        fishSC.setStudyParticipantCriteria(sc);
        fishSC.setStudyParticipantCriteriaOpType(OperatorType.OR);
    }

    private void executeSearch() {
        Collection<? extends SpecimenBasedMolecularFinding> findings = FindingsManager.getFindings(fishSC);
        for (Iterator<? extends SpecimenBasedMolecularFinding> iterator = findings.iterator(); iterator.hasNext();) {
            FISHFinding fishFinding =  (FISHFinding)iterator.next();
            System.out.println("FISH Fact ID:" + fishFinding.getId());
            System.out.println("GeneBasedBiomarker:");
            print(fishFinding.getGeneBasedBiomarker());

            System.out.println("CNA Status: " + fishFinding.getCnaStatus());
            System.out.println("Ratio : " + fishFinding.getRatio());
            System.out.println("Reference Name: " + fishFinding.getReferenceName());
            System.out.println("Biomarker Nuclei: " + fishFinding.getBiomarkerNuclei());
            System.out.println("Reference Nuclei: " + fishFinding.getReferenceNuclei());

            Specimen specimen = fishFinding.getSpecimen();
            assert(specimen != null);
            print(specimen);

            StudyParticipant studyParticipant = specimen.getStudyParticipant();
            print(studyParticipant );
        }
        System.out.println("Results FOund: "+ findings.size());
    }

    public void testGeneOntologyCriteria() {
        AnnotationCriteria annotCrit = new AnnotationCriteria ();
        Collection<String> goIDs = new ArrayList<String>();
        //goIDs.add("GO:0001533");
        goIDs.add("GO:0005006");
        annotCrit.setGeneOntologyIDs(goIDs);
        //setGeneBiomarkerSearchCriteria();
        setReferenceName();
        fishSC.setAnnotationCriteria(annotCrit);
        executeSearch();

    }

    public void testPathwayCriteria() {
        AnnotationCriteria annotCrit = new AnnotationCriteria ();
        Collection<String> pathways = new ArrayList<String>();
        pathways.add("her2Pathway");
        annotCrit.setPathways(pathways);

        // set another Annotation
        Collection<LocusLink> locusLinks= new ArrayList<LocusLink>();
        LocusLink o = new LocusLink();
        o.setValue("7153"); //7153 for TOP2A
        locusLinks.add(o);
        annotCrit.setGeneIdentifiers(locusLinks);

        annotCrit.setOperatorType(OperatorType.OR);

        //setGeneBiomarkerSearchCriteria();
        setRaioCrit();
        fishSC.setAnnotationCriteria(annotCrit);
        fishSC.setAnnotationCriteriaOpType(OperatorType.OR);
        executeSearch();

    }

    public void testAccessionCriteria() {
        AnnotationCriteria annotCrit = new AnnotationCriteria ();
        Collection<GeneAccession> accessions = new ArrayList<GeneAccession>();
        GeneAccession o = new GeneAccession();
        o.setValue("AB025286"); //X03363, AB025286, M11730 -- all are for ERBB2
        accessions.add(o);

        GeneAccession o1 = new GeneAccession();
        o.setValue("X03363");
        accessions.add(o1);

        annotCrit.setGeneIdentifiers(accessions);
        //setGeneBiomarkerSearchCriteria();
        fishSC.setAnnotationCriteriaOpType(OperatorType.AND);
        fishSC.setAnnotationCriteria(annotCrit);

        // set StudyPartcipantCriteria
        setParticipantCriteria();
        //setSpecimenCriteria();
        executeSearch();

    }
     public void testLocusLinkCriteria() {

        //setGeneBiomarkerSearchCriteria();

        AnnotationCriteria annotCrit = new AnnotationCriteria ();
        Collection<LocusLink> locusLinks= new ArrayList<LocusLink>();
        LocusLink o = new LocusLink();
        o.setValue("7153"); //7153 for TOP2A
        locusLinks.add(o);
        annotCrit.setGeneIdentifiers(locusLinks);
        fishSC.setAnnotationCriteria(annotCrit);
        fishSC.setAnnotationCriteriaOpType(OperatorType.AND);

        // set StudyPartcipantCriteria
        setParticipantCriteria();

        executeSearch();

    }

    public void testPathwayAndLocusLinkCrit() {
        AnnotationCriteria annotCrit = new AnnotationCriteria ();
        Collection<LocusLink> locusLinks= new ArrayList<LocusLink>();
        LocusLink ll1 = new LocusLink();
        ll1.setValue("7153"); //for TOP2A
        LocusLink ll2 = new LocusLink();
        ll2.setValue("2064");   // for ERBB2
        locusLinks.add(ll1);
        locusLinks.add(ll2);
        annotCrit.setGeneIdentifiers(locusLinks);

        Collection<String> pathways = new ArrayList<String>();
        pathways.add("her2Pathway");     // ERBB2 gene symbol
        pathways.add("DNAfragmentPathway"); // TOP2A gene symbol
        annotCrit.setPathways(pathways);
        // SET THE OPERATOR for ANNOATION CRITERIA OBJECTS
        annotCrit.setOperatorType(OperatorType.AND);
        fishSC.setAnnotationCriteria(annotCrit);

        setGeneBiomarkerSearchCriteria(); // sets TOP2A
        fishSC.setAnnotationCriteriaOpType(OperatorType.AND);

        executeSearch();

    }
    public void testPathwayAndGeneBasedCrit() {
        setGeneBiomarkerSearchCriteria();
        AnnotationCriteria annotCrit = new AnnotationCriteria ();
        Collection<String> pathways = new ArrayList<String>();
        pathways.add("her2Pathway");     // ERBB2 gene symbol
        annotCrit.setPathways(pathways);
         setGeneBiomarkerSearchCriteria();
         fishSC.setAnnotationCriteria(annotCrit);
         fishSC.setAnnotationCriteriaOpType(OperatorType.OR);
         executeSearch();
    }
    private void print(Specimen specimen) {
        System.out.println("   Specimen: ");
        System.out.println("            Specimen ID;    " + specimen.getSpecimenID());
        System.out.println("            Sampling Type:  "+ specimen.getSamplingType());
        System.out.println("            GenoType:       " + specimen.getGenoType());
        System.out.println("            TimeCourse:       " + specimen.getTimeCourse());
    }
    private void print(StudyParticipant studyParticipant ) {
        System.out.println("\n            Study Partcipant:");
        System.out.println("                             ParticipantDID: " + studyParticipant.getStudyPartcipantIdentifier());
        System.out.println("                             Gender: " + studyParticipant.getAdministrativeGenderCode());
        System.out.println("                             AgeAtDiagnosis: " + studyParticipant.getAgeAtDiagnosis());
        System.out.println("                             AgeAtEnrollment: " + studyParticipant.getAgeAtEnrollment());
        System.out.println("                             EthnicGroupCode: " + studyParticipant.getEthnicGroupCode());
        System.out.println("                             InstitutionName: " + studyParticipant.getInstitutionName());
        System.out.println("                             RaceCode: " + studyParticipant.getRaceCode());
        System.out.println("                             Survival Status: " + studyParticipant.getSurvivalStatus());
        System.out.println("                             Off Study: " + studyParticipant.getOffStudy());
    }
    private void print(GeneBasedBiomarker biomarker) {
         System.out.println("   Biomarker Name: " + biomarker.getGeneSymbol().getValue());
         GeneAnnotation geneAnnot = biomarker.getBioMarkerAnnotation();

         // print Biomarker Annotation
         System.out.println("   Annotation: ");
         System.out.println("       Gene LocusLink: " + geneAnnot.getLocusLink().getValue());

         // print Gene Accessions
        Collection<GeneAccession> geneAccns = geneAnnot.getGeneAccessions();
         System.out.print("         GeneAccessions: ");
         for (Iterator<GeneAccession> iterator = geneAccns.iterator(); iterator.hasNext();) {
             GeneAccession accession = iterator.next();
             System.out.print(accession.getValue() + "  ");
         }
         System.out.println("\n");

         // print Gene Pathways
         Collection<String> genePathways = geneAnnot.getPathways();
         System.out.print("         GenePathways: ");
         for (Iterator<String> iterator = genePathways.iterator(); iterator.hasNext();) {
             String genePathway = iterator.next();
             System.out.print(genePathway + "  ");
         }
         System.out.println("\n");

         // print Gene Pathways
         Collection<String> geneOntologyIDs = geneAnnot.getGeneOntologyIDs();
         System.out.print("         GeneOntologyIDs: ");
         for (Iterator<String> iterator = geneOntologyIDs.iterator(); iterator.hasNext();) {
             String geneOntologyID = iterator.next();
             System.out.print(geneOntologyID + "  ");
         }
         System.out.println("\n");

     }
     public static Test suite() {
        TestSuite suit =  new TestSuite();
        suit.addTest(new TestSuite(FISHFindingTest.class));
        return suit;
    }

    public static void main (String[] args) {
        junit.textui.TestRunner.run(suite());

    }
}
