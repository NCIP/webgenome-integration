package gov.nih.nci.cg.findings;

import java.util.Set;
import java.util.HashSet;


/**
 * User: Ram Bhattaru <BR>
 * Date: Apr 4, 2006 <BR>
 * Version: 1.0 <BR>
 */
public class GeneBasedBiomarker extends Biomarker{
    public final static String GENE_SYMBOL = "geneSymbol";
    private String id;
    private GeneSymbol geneSymbol ;
    private GeneAnnotation bioMarkerAnnotation;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public GeneBasedBiomarker(){

    }

    public GeneSymbol getGeneSymbol() {
        return geneSymbol;
    }

    public void setGeneSymbol(GeneSymbol geneSymbol) {
        this.geneSymbol = geneSymbol;
    }

   public GeneAnnotation getBioMarkerAnnotation() {
        return bioMarkerAnnotation;
    }

    public void setBioMarkerAnnotation(GeneAnnotation bioMarkerAnnotation) {
        this.bioMarkerAnnotation = bioMarkerAnnotation;
    }


}