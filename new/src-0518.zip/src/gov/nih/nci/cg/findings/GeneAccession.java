package gov.nih.nci.cg.findings;

import java.io.Serializable;

/**
 * User: Ram Bhattaru <BR>
 * Date: Apr 4, 2006 <BR>
 * Version: 1.0 <BR>
 */
public class GeneAccession extends GeneIdentifier implements Serializable{
    public final static String GENE_SYMBOL = "geneSymbol";
    public GeneAccession(String value) {
        super(value);
    }

    public GeneAccession() {
    }
    private String geneSymbol;

    public String getGeneSymbol() {
        return geneSymbol;
    }

    public void setGeneSymbol(String geneSymbol) {
        this.geneSymbol = geneSymbol;
    }

}
