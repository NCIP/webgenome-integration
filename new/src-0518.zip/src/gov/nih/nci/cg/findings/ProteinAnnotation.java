package gov.nih.nci.cg.findings;

/**
  *
  * User: Ram Bhattaru <BR>
  * Date: Mar 30, 2006 <BR>
  * Version: 1.0 <BR>
 */
public class ProteinAnnotation {

	private String[] alias;
	private String geneSymbol;
	private String[] primaryAccessions;

	public ProteinAnnotation(){

	}

	public void finalize() throws Throwable {

	}

}