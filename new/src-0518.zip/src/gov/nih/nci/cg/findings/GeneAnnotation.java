package gov.nih.nci.cg.findings;

import org.hibernate.Session;

import java.util.Collection;

import gov.nih.nci.cg.util.HibernateUtil;

/**
 * User: Ram Bhattaru <BR>
 * Date: Apr 4, 2006 <BR>
 * Version: 1.0 <BR>
 */

public class GeneAnnotation {
    public final static String GENE_ONTOLOGIES = "geneOntologyIDs";
    public final static String PATHWAYS = "pathways";
    public final static String ACCESIIONS = "accessions";
    public final static String ID = "id";
    public final static String LOCUS_LINK = "locusLink";
    private String id;
    private Collection<GeneAccession> geneAccessions;
    //private String chromosome;
    //private String cytoband;
    private Collection<String> geneOntologyIDs;
    private LocusLink locusLink;
    private Collection<String> pathways;
    private String geneName;

    public Collection<String> getGeneOntologyIDs() {
        return geneOntologyIDs;
    }

    public void setGeneOntologyIDs(Collection<String> geneOntologyIDs) {
        this.geneOntologyIDs = geneOntologyIDs;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public GeneAnnotation(){

    }

    public Collection<GeneAccession> getGeneAccessions() {
        return geneAccessions;
    }

    public void setGeneAccessions(Collection<GeneAccession> geneAccessions) {
        this.geneAccessions = geneAccessions;
    }

    public LocusLink getLocusLink() {
        return locusLink;
    }

    public void setLocusLink(LocusLink locusLink) {
        this.locusLink = locusLink;
    }

    public Collection<String> getPathways() {
        return pathways;
    }

    public void setPathways(Collection<String> pathways) {
        this.pathways = pathways;
    }

    public String getGeneName() {
        return geneName;
    }

    public void setGeneName(String geneName) {
        this.geneName = geneName;
    }
}