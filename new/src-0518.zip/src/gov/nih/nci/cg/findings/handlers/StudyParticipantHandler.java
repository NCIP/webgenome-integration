package gov.nih.nci.cg.findings.handlers;

import gov.nih.nci.cg.criteria.StudyParticipantCriteria;
import gov.nih.nci.cg.criteria.SpecimenCriteria;
import gov.nih.nci.cg.criteria.PatientCriteria;
import gov.nih.nci.cg.enums.OperatorType;
import gov.nih.nci.cg.findings.SpecimenBasedMolecularFinding;
import gov.nih.nci.cg.findings.StudyParticipant;
import gov.nih.nci.cg.findings.TimeCourse;
import org.hibernate.Session;
import org.hibernate.Query;
import org.hibernate.criterion.Criterion;

import java.util.*;

/**
 * User: Ram Bhattaru <BR>
 * Date: Apr 25, 2006 <BR>
 * Version: 1.0 <BR>
 */
public abstract class StudyParticipantHandler {

     /* template method that will be implemented by all child classes of StudyParticipantHandler
        to apply apply Specimen criteria   */
    protected  abstract void applySpecimenCrit(StudyParticipantCriteria studyCrit, StringBuffer finalHSQL, HashMap params);

    /**
    * This method adds the required criteria to handle the StudyParticipantCriteria to the
    * target findings based on the operator specified.
    *
    * @param studyCrit Any sub types of StudyParticipantCriteria
    * @param opType  The operator used to add this StudyParticipantCriteria  to filter the target findings
    * @param targetFindingType Required type of Finding (which is a sub type of SpecimenBasedMolecularFinding class
    * @param hSQL hSQL String that has the required criteria to handle SpecimenBasedFindingSearchCriteria
    *        correponding to targetFindingType of finding
    * @param params Parameter Values that need to be set on above parameter hSQL
    * @param session Hibernate session object
    */
    public Collection<? extends SpecimenBasedMolecularFinding> searchFindings(StudyParticipantCriteria studyCrit, OperatorType opType,  Class targetFindingType, StringBuffer hSQL, HashMap params, Session session) {
            Collection<? extends SpecimenBasedMolecularFinding> findings = null;
            String condition = (opType == OperatorType.AND) ? " AND " : " OR ";
             Criterion c = null;
             
            // remove any trailing AND/OR
            String interHSQL = SpecimenFindingHandler.removeTrailingAND(hSQL);
            String tmpHSQL = SpecimenFindingHandler.removeTrailingOR(new StringBuffer(interHSQL));

            // add AND/OR before adding Specimen criteria based on the above operator
            StringBuffer finalHSQL = new StringBuffer(tmpHSQL + condition);

            //template method for applying Specimen criteria
            applySpecimenCrit(studyCrit, finalHSQL, params);

            Query q = session.createQuery(finalHSQL.toString());
            SpecimenFindingHandler.setParamsOnQuery(params, q);
            findings = q.list();

            return findings;
       }

    public static class SpecimenHandler extends StudyParticipantHandler {
       protected void applySpecimenCrit(StudyParticipantCriteria studyCrit, StringBuffer finalHSQL, HashMap params) {
           SpecimenCriteria spCrit = (SpecimenCriteria) studyCrit;
           Collection<String> specimenIDs = spCrit.getSpecimenIDs();
           finalHSQL.append( " f.specimen IN ( FROM Specimen s WHERE s.specimenID IN (:spIDs) ) ");
           params.put("spIDs", specimenIDs);
       }
    }

    public static class PatientHandler extends StudyParticipantHandler {
       /* This method converts PatientCriteria (which in turn contains PatientDID and/or timeCourse
           in to SpecimenCriteria.  */
       protected void applySpecimenCrit(StudyParticipantCriteria studyCrit, StringBuffer finalHSQL, HashMap params) {
           PatientCriteria patientCrit = (PatientCriteria) studyCrit;

           // 1. Handle studySubjectIdentifiers (patientDIDs)
           Collection<String> studySubjectIdentifiers = patientCrit.getStudySubjectIdentifiers();
           Collection<StudyParticipant> spList = new ArrayList<StudyParticipant>();
           for (Iterator<String> iterator = studySubjectIdentifiers.iterator(); iterator.hasNext();) {
               String s = iterator.next();
               StudyParticipant sp = new StudyParticipant();
               sp.setStudyPartcipantIdentifier(s);
               spList.add(sp);
           }
           finalHSQL.append( " f.specimen IN ( FROM Specimen s WHERE s.studyParticipant IN (:spList)) ");
           params.put("spList", spList);

           // 2. Handle studySubjectIdentifiers (patientDIDs)
           Collection<TimeCourse> timeCourses = patientCrit.getTimeCourse();
           Collection<StudyParticipant> tcList = new ArrayList<StudyParticipant>();
           if ((timeCourses != null) && timeCourses.size() > 0 ) {
                finalHSQL.append( " AND f.specimen IN ( FROM Specimen s WHERE s.timeCourse IN (:tcpList)) ");
                params.put("tcpList", timeCourses);
           }
       }
    }

}
