package gov.nih.nci.cg.criteria;

/**
 * User: Ram Bhattaru <BR>
 * Date: Mar 19, 2006 <BR>
 * Version: 1.0 <BR>
 */

public class DiseaseCriteria extends StudyParticipantCriteria {

	private String name;
	private String[] timeCourses;

	public DiseaseCriteria(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}

}