package gov.nih.nci.cg.enums.ihc;

/**
 * Borderline, Moderate, Strong, Negative, Weak
 *
 * User: Ram Bhattaru <BR>
 * Date: Mar 29, 2006 <BR>
 * Version: 1.0 <BR>
 */
public enum IntensityOfStain {
	Borderline,
	Moderate,
	Negative,
	Strong,
	Weak
}