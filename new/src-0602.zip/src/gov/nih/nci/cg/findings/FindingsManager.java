package gov.nih.nci.cg.findings;

import gov.nih.nci.cg.criteria.SpecimenBasedFindingSearchCriteria;

import java.util.Collection;

/**
 * User: Ram Bhattaru <BR>
 * Date: Apr 4, 2006 <BR>
 * Version: 1.0 <BR>
 */
public class FindingsManager {
        public static Collection<? extends SpecimenBasedMolecularFinding> getFindings(SpecimenBasedFindingSearchCriteria sc) {
        return sc.getHandler().getFindings(sc);
    }
}
