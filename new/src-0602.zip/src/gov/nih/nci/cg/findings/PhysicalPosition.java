package gov.nih.nci.cg.findings;

/**
 * User: Ram Bhattaru <BR>
 * Date: Mar 19, 2006 <BR>
 * Version: 1.0 <BR>
 */

public class PhysicalPosition {

	private String chromosome;
	private Long endPostion;
	private Long startPosition;

	public PhysicalPosition(){

	}

	public void finalize() throws Throwable {

	}

}