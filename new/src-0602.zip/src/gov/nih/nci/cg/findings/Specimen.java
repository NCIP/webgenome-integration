package gov.nih.nci.cg.findings;



/**
 * User: Ram Bhattaru <BR>
 * Date: Mar 19, 2006 <BR>
 * Version: 1.0 <BR>
 */

/**
 * A part of a thing, or of several things, removed to demonstrate or to determine
 * the character of the whole, e.g. a substance, or portion of material obtained
 * for use in testing, examination, or study; particularly, a preparation of
 * tissue or bodily fluid taken for observation, examination or diagnosis.
 * 
 * NOTE: Can be a sample of a collection or biopsy. (arc relationship)
 *
  * User: Ram Bhattaru <BR>
  * Date: Mar 30, 2006 <BR>
  * Version: 1.0 <BR>
 */
public class Specimen {
     public final static String SPECIMEN_ID = "specimenID";
     public final static String STUDY_PARTICIPANT = "studyParticipant";
    /**
	 * For CGEMS (e.g Human/Mouse ????)
	 */
	private String genoType;
	/**
	 * Type of specimen/body tissue being sampled, using an enumerated set of values.
	 * Values include: V  Saliva, A  Aphaeresis Cells, B Whole Blood, C  CSF, D  CD33
	 * Myeloid Cells, L  CD3 Lymphoid Cells, M  PBMC Peripheral Blood Mononuclear
	 * Cells, O Bone Marrow,
	 * P  Plasma, S  Serum, T  Tumor Tissue, U  Urine, Y  CD14/CD15 Myeloid Cells.    
	 */
    private String samplingType;

	/**
	 * A unique sample, I.D. number  (Is this the unique specimen identifier - USI?)
	 */
	private String specimenID;
	private TimeCourse timeCourse;
	private StudyParticipant studyParticipant;
   /* Set<FISHFinding> fishFindings ;

    public Set<FISHFinding> getFishFindings() {
        return fishFindings;
    }

    public void setFishFindings(Set<FISHFinding> fishFindings) {
        this.fishFindings = fishFindings;
    }
*/
    public Specimen(){}

    public String getGenoType() {
        return genoType;
    }

    public void setGenoType(String genoType) {
        this.genoType = genoType;
    }

    public String getSamplingType() {
        return samplingType;
    }

    public void setSamplingType(String samplingType) {
        this.samplingType = samplingType;
    }

    public String getSpecimenID() {
        return specimenID;
    }

    public void setSpecimenID(String specimenID) {
        this.specimenID = specimenID;
    }

    public TimeCourse getTimeCourse() {
        return timeCourse;
    }

    public void setTimeCourse(TimeCourse timeCourse) {
        this.timeCourse = timeCourse;
    }

    public StudyParticipant getStudyParticipant() {
        return studyParticipant;
    }

    public void setStudyParticipant(StudyParticipant studyParticipant) {
        this.studyParticipant = studyParticipant;
    }

    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        final Specimen specimen = (Specimen) o;

        if (specimenID != null ? !specimenID.equals(specimen.specimenID) : specimen.specimenID != null) return false;

        return true;
    }

    public int hashCode() {
        return (specimenID != null ? specimenID.hashCode() : 0);
    }

}