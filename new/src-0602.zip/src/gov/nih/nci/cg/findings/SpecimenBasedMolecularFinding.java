package gov.nih.nci.cg.findings;

/**
 * User: Ram Bhattaru <BR>
 * Date: Mar 19, 2006 <BR>
 * Version: 1.0 <BR>
 */

public abstract class SpecimenBasedMolecularFinding {

    //private Specimen specimen;

    public SpecimenBasedMolecularFinding(){

    }

    /*public void setSpecimen(Specimen specimen) {
        this.specimen = specimen;
    }
*/
    public abstract Specimen getSpecimen() ;

}