package gov.nih.nci.cg.criteria;

import java.util.Collection;

/**
 * User: Ram Bhattaru <BR>
 * Date: Mar 19, 2006 <BR>
 * Version: 1.0 <BR>
 */

public class SpecimenCriteria extends StudyParticipantCriteria {

    private Collection<String> specimenIDs;

    public SpecimenCriteria(){
    }

    public Collection<String> getSpecimenIDs() {
        return specimenIDs;
    }

    public void setSpecimenIDs(Collection<String> specimenIDs) {
        this.specimenIDs = specimenIDs;
    }
}