package gov.nih.nci.cg.criteria;

import gov.nih.nci.cg.findings.ProteinBiomarker;
import gov.nih.nci.cg.findings.handlers.SpecimenFindingHandler;
import gov.nih.nci.cg.findings.handlers.IHCFindingHandler;
import gov.nih.nci.cg.enums.ihc.DistributionOfStain;
import gov.nih.nci.cg.enums.ihc.ResultCode;
import gov.nih.nci.cg.enums.ihc.IntensityOfStain;
import gov.nih.nci.cg.enums.ihc.LocalizationOfStain;

/**
 * User: Ram Bhattaru <BR>
 * Date: May 31, 2006 <BR>
 * Version: 1.0 <BR>
 */

public class IHCFindingSearchCriteria extends SpecimenBasedFindingSearchCriteria {

    private DistributionOfStain distributionOfStain ;
    private IntensityOfStain intensityOfStain;
    private LocalizationOfStain localizationOfStain;
    private Integer percentPositive;
    private ResultCode resultCode;

    public IHCFindingSearchCriteria(){

    }

    public SpecimenFindingHandler getHandler() {
        return new IHCFindingHandler();
    }

    /**
     *
     * @param bioMarkers
     */
    public ProteinBiomarker setProteinBiomaker(ProteinBiomarker[] bioMarkers){
        return null;
    }

}