package gov.nih.nci.cg.criteria;

/**
 * User: Ram Bhattaru <BR>
 * Date: Mar 19, 2006 <BR>
 * Version: 1.0 <BR>
 */

public class DiseaseGradeCriteria extends StudyParticipantCriteria {

	private String diseaseGrade;
	private String[] timeCourses;

	public DiseaseGradeCriteria(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}

}