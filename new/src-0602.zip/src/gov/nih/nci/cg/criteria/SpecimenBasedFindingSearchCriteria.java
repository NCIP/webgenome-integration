package gov.nih.nci.cg.criteria;

import gov.nih.nci.cg.enums.OperatorType;
import gov.nih.nci.cg.enums.OperatorType;
import gov.nih.nci.cg.findings.handlers.SpecimenFindingHandler;
import gov.nih.nci.cg.findings.handlers.SpecimenFindingHandler;


/**
 * User: Ram Bhattaru <BR>
 * Date: Apr 4, 2006 <BR>
 * Version: 1.0 <BR>          
 */

public abstract class SpecimenBasedFindingSearchCriteria {
    public abstract SpecimenFindingHandler getHandler();
    private AnnotationCriteria annotationCriteria;
    private OperatorType annotationCriteriaOpType;
    private StudyParticipantCriteria studyParticipantCriteria;
    private OperatorType studyParticipantCriteriaOpType;

    public SpecimenBasedFindingSearchCriteria(){

    }

    public AnnotationCriteria getAnnotationCriteria() {
        return annotationCriteria;
    }

    public void setAnnotationCriteria(AnnotationCriteria annotationCriteria) {
        this.annotationCriteria = annotationCriteria;
    }

    public OperatorType getAnnotationCriteriaOpType() {
        return annotationCriteriaOpType;
    }

    public void setAnnotationCriteriaOpType(OperatorType annotationCriteriaOpType) {
        this.annotationCriteriaOpType = annotationCriteriaOpType;
    }

    public StudyParticipantCriteria getStudyParticipantCriteria() {
        return studyParticipantCriteria;
    }

    public void setStudyParticipantCriteria(StudyParticipantCriteria studyParticipantCriteria) {
        this.studyParticipantCriteria = studyParticipantCriteria;
    }

    public OperatorType getStudyParticipantCriteriaOpType() {
        return studyParticipantCriteriaOpType;
    }

    public void setStudyParticipantCriteriaOpType(OperatorType studyParticipantCriteriaOpType) {
        this.studyParticipantCriteriaOpType = studyParticipantCriteriaOpType;
    }

  

}