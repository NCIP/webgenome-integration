package gov.nih.nci.cg.criteria;

import gov.nih.nci.cg.findings.Cytoband;
import gov.nih.nci.cg.findings.GeneIdentifier;
import gov.nih.nci.cg.findings.PhysicalPosition;
import gov.nih.nci.cg.enums.OperatorType;

import java.util.Collection;


/**
 * User: Ram Bhattaru <BR>
 * Date: Mar 19, 2006 <BR>
 * Version: 1.0 <BR>
 */
public class AnnotationCriteria {
    private Cytoband cytoband;
    private Collection<? extends GeneIdentifier> geneIdentifiers;
    private Collection<String> geneOntologyIDs;
    private Collection<String> pathways;
    private OperatorType operatorType;

    public Cytoband getCytoband() {
        return cytoband;
    }

    public Collection<? extends GeneIdentifier> getGeneIdentifiers() {
        return geneIdentifiers;
    }

    public Collection<String> getGeneOntologyIDs() {
        return geneOntologyIDs;
    }

    public Collection<String> getPathways() {
        return pathways;
    }

    public OperatorType getOperatorType() {
        return operatorType;
    }

    public AnnotationCriteria(){

    }
    /**
     *
     * @param cytoband
     */
    public void setCytoband(Cytoband cytoband){
        this.cytoband = cytoband;
    }

    /**
     *
     * @param geneIdentifiers
     */
    public void setGeneIdentifiers(Collection<? extends GeneIdentifier> geneIdentifiers){
         this.geneIdentifiers = geneIdentifiers;
    }

    /**
     *
     * @param geneOntologyIDs
     */
    public void setGeneOntologyIDs(Collection<String> geneOntologyIDs){
          this.geneOntologyIDs = geneOntologyIDs;
    }

    /**
     *
     * @param operatorType
     */
    public void setOperatorType(OperatorType operatorType){
           this.operatorType = operatorType;
    }

    /**
     *
     * @param pathways
     */
    public void setPathways(Collection<String>  pathways){
          this.pathways = pathways;
    }

    /**
     *
     * @param physicalPosition
     */
    public void setPhysicalPosition(PhysicalPosition physicalPosition){
          
    }

    /**
     *
     * @param snpIdentifiers
     */
    //TODO: uncomment this
    //public void setSnpIdentifiers(SnpIdentifier[] snpIdentifiers){

    //}

}