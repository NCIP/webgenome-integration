package gov.nih.nci.cg.criteria;

import gov.nih.nci.cg.findings.GeneSymbol;

import java.util.Collection;
import java.util.ArrayList;

/**
 * User: Ram Bhattaru <BR>
 * Date: Apr 6, 2006 <BR>
 * Version: 1.0 <BR>
 */
public class GeneBiomarkerSearchCriteria {
    Collection<GeneSymbol>  geneSymbols;

    public GeneBiomarkerSearchCriteria() {
        geneSymbols =  new ArrayList<GeneSymbol>();
    }

    public GeneBiomarkerSearchCriteria(Collection<GeneSymbol> geneSymbols) {
        this.geneSymbols = geneSymbols;
    }

    public Collection<GeneSymbol> getGeneSymbols() {
        return geneSymbols;
    }

    public void setGeneSymbols(Collection<GeneSymbol> geneSymbols) {
        this.geneSymbols = geneSymbols;
    }
}
