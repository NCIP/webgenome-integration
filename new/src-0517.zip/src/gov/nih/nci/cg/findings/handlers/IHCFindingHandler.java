package gov.nih.nci.cg.findings.handlers;


import gov.nih.nci.cg.findings.SpecimenBasedMolecularFinding;
import gov.nih.nci.cg.findings.IHCFinding;
import gov.nih.nci.cg.criteria.SpecimenBasedFindingSearchCriteria;

import java.util.Collection;
import java.util.HashMap;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.Query;

/**
 * User: Ram Bhattaru <BR>
 * Date: Mar 13, 2006 <BR>
 * Version: 1.0 <BR>
 */
public class IHCFindingHandler extends SpecimenFindingHandler {

    protected StringBuffer handle(SpecimenBasedFindingSearchCriteria sc, HashMap params, Session session) {
        // TODO: Implement this and return IHCFindings[] objects
        //return new IHCFinding[];
        return null;
    }


    public Class getFindingType() {
        return IHCFinding.class;
    }

    public void initializeProxies(Collection<? extends SpecimenBasedMolecularFinding> findings) {
        //To change body of implemented methods use File | Settings | File Templates.
    }
}
