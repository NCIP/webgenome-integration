package gov.nih.nci.cg.findings;

/**
 * User: Ram Bhattaru <BR>
 * Date: Mar 19, 2006 <BR>
 * Version: 1.0 <BR>
 */

public enum BioAssayArrayType {
	    ONE_HUNDRED_K_SNP_ARRAY,
	    CDNA_ARRAY,
	    U133_P52_HG
}