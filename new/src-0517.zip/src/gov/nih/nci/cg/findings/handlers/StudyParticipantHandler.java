package gov.nih.nci.cg.findings.handlers;

import gov.nih.nci.cg.criteria.StudyParticipantCriteria;
import gov.nih.nci.cg.criteria.SpecimenCriteria;
import gov.nih.nci.cg.criteria.PatientCriteria;
import gov.nih.nci.cg.enums.OperatorType;
import gov.nih.nci.cg.findings.Specimen;
import gov.nih.nci.cg.findings.SpecimenBasedMolecularFinding;
import gov.nih.nci.cg.findings.StudyParticipant;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.Query;
import org.hibernate.criterion.Restrictions;
import org.hibernate.criterion.Projection;
import org.hibernate.criterion.Criterion;


import java.util.*;

/**
 * User: Ram Bhattaru <BR>
 * Date: Apr 25, 2006 <BR>
 * Version: 1.0 <BR>
 */
public abstract class StudyParticipantHandler {

    /**
     * This method adds the required criteria to handle the StudyParticipantCriteria to the
     * target findings.  It includes the StudyParticipantCriteria to the actual finding criteria
     * (target findings) based on the operator specified.
     * @param studyCrit Any sub types of StudyParticipantCriteria
     * @param opType  The operator used to add this StudyParticipantCriteria  to filter the target findings
     * @param targetFindingType Required type of Finding (which is a sub type of SpecimenBasedMolecularFinding class
     * @param findingCrit Hibernate criteria class that has the required criteria to handle SpecimenBasedFindingSearchCriteria
     *        correponding to  targetFindingType of finding
     * @param session Hibernate session object
     */
   public abstract Collection<? extends SpecimenBasedMolecularFinding>  searchFindings(StudyParticipantCriteria studyCrit, OperatorType opType,  Class targetFindingType, StringBuffer hSQL, HashMap params, Session session);

   public static class SpecimenHandler extends StudyParticipantHandler {
       public Collection<? extends SpecimenBasedMolecularFinding> searchFindings(StudyParticipantCriteria studyCrit, OperatorType opType,  Class targetFindingType, StringBuffer hSQL, HashMap params, Session session) {
            Collection<? extends SpecimenBasedMolecularFinding> findings = new ArrayList();
            SpecimenCriteria spCrit = (SpecimenCriteria) studyCrit;
            Collection<String> specimenIDs = spCrit.getSpecimenIDs();
            String condition = (opType == OperatorType.AND) ? " AND " : " OR ";

            // remove any trailing AND
            String interHSQL = SpecimenFindingHandler.removeTrailingAND(hSQL);

            // add AND / OR before adding Specimen criteria based on the above operator
            StringBuffer finalHSQL = new StringBuffer(interHSQL + condition);

            finalHSQL.append( " f.specimen IN ( FROM Specimen s WHERE s.specimenID IN (:spIDs) ) ");
            params.put("spIDs", specimenIDs);

            Query q = session.createQuery(finalHSQL.toString());
            SpecimenFindingHandler.setParamsOnQuery(params, q);

            findings = q.list();
            return findings;
       }
   }
   public static class PatientHandler extends StudyParticipantHandler {
         public Collection<? extends SpecimenBasedMolecularFinding>  searchFindings(StudyParticipantCriteria studyCrit, OperatorType opType, Class targetFindingType, StringBuffer hSQL, HashMap params, Session session) {
             PatientCriteria patientCrit = (PatientCriteria) studyCrit;

             // convert this patientCrit in to SpecimenCriteria

             Collection<String> studySubjectIdentifiers = patientCrit.getStudySubjectIdentifiers();

             Collection<StudyParticipant> spList = new ArrayList<StudyParticipant>();
             for (Iterator<String> iterator = studySubjectIdentifiers.iterator(); iterator.hasNext();) {
               String s = iterator.next();
               StudyParticipant sp = new StudyParticipant();
               sp.setStudyPartcipantIdentifier(s);
               spList.add(sp);
               /*Specimen spmn = new Specimen();
                   spmn.setStudyParticipant(sp);
                   specimenList.add(spmn);*/
              }

              Query hibQuery = session.createQuery(" SELECT  distinct s.specimenID FROM Specimen s WHERE s.studyParticipant IN (:spList) AND ");
              hibQuery.setParameterList("spList", spList);
              List specimenIDs = hibQuery.list();

              SpecimenCriteria sc = new SpecimenCriteria();
              sc.setSpecimenIDs(specimenIDs);

              SpecimenHandler sh = new SpecimenHandler();
              return sh.searchFindings(sc, opType, targetFindingType, hSQL, params, session);
        }
   }

}
