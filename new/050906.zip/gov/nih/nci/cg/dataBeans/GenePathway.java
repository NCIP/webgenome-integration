package gov.nih.nci.cg.dataBeans;

import java.io.Serializable;

/**
 * User: Ram Bhattaru <BR>
 * Date: Apr 6, 2006 <BR>
 * Version: 1.0 <BR>
 */
public class GenePathway implements Serializable {
    public final static String GENE_SYMBOL = "geneSymbol";
    public final static String GENE_PATHWAY = "genePathway";

    private String genePathway;
    private String geneSymbol;

    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        final GenePathway that = (GenePathway) o;

        if (genePathway != null ? !genePathway.equals(that.genePathway) : that.genePathway != null) return false;
        if (geneSymbol != null ? !geneSymbol.equals(that.geneSymbol) : that.geneSymbol != null) return false;

        return true;
    }

    public int hashCode() {
        int result;
        result = (genePathway != null ? genePathway.hashCode() : 0);
        result = 29 * result + (geneSymbol != null ? geneSymbol.hashCode() : 0);
        return result;
    }

    public String getGenePathway() {
        return genePathway;
    }

    public void setGenePathway(String genePathway) {
        this.genePathway = genePathway;
    }

    public String getGeneSymbol() {
        return geneSymbol;
    }

    public void setGeneSymbol(String geneSymbol) {
        this.geneSymbol = geneSymbol;
    }
}
