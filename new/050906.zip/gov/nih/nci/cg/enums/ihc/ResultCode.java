package gov.nih.nci.cg.enums.ihc;

/**
 * 2-Invasive
 *
 * User: Ram Bhattaru <BR>
 * Date: Mar 29, 2006 <BR>
 * Version: 1.0 <BR>
*/
public enum ResultCode {
	Two_Invasive
}