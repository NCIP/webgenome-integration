package gov.nih.nci.cg.findings;

import gov.nih.nci.cg.enums.ihc.LocalizationOfStain;
import gov.nih.nci.cg.enums.ihc.DistributionOfStain;
import gov.nih.nci.cg.enums.ihc.IntensityOfStain;
import gov.nih.nci.cg.enums.ihc.ResultCode;

/**
  *
  * User: Ram Bhattaru <BR>
  * Date: Mar 29, 2006 <BR>
  * Version: 1.0 <BR>
 */
public class IHCFinding extends SpecimenBasedMolecularFinding {

    private DistributionOfStain distributionOfStain ;
    private IntensityOfStain intensityOfStain ;
    private LocalizationOfStain localizationOfStain ;
    private Integer percentPositive;
    private ResultCode resultCode;
    public ProteinBiomarker proteinBasedMarker;
    private Specimen specimen;

    public Specimen getSpecimen() {
        return specimen;
    }

    public void setSpecimen(Specimen specimen) {
        this.specimen = specimen;
    }

    public IHCFinding(){

    }

    public void finalize() throws Throwable {
        super.finalize();
    }

    public ProteinBiomarker getProteinBiomaker(){
        return null;
    }

}