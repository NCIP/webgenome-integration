package gov.nih.nci.cg.findings.handlers;

import gov.nih.nci.cg.criteria.StudyParticipantCriteria;
import gov.nih.nci.cg.criteria.SpecimenCriteria;
import gov.nih.nci.cg.criteria.PatientCriteria;
import gov.nih.nci.cg.enums.OperatorType;
import gov.nih.nci.cg.findings.Specimen;
import gov.nih.nci.cg.findings.SpecimenBasedMolecularFinding;
import gov.nih.nci.cg.findings.StudyParticipant;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.Query;
import org.hibernate.criterion.Restrictions;
import org.hibernate.criterion.Projection;


import java.util.Collection;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;

/**
 * User: Ram Bhattaru <BR>
 * Date: Apr 25, 2006 <BR>
 * Version: 1.0 <BR>
 */
public abstract class StudyParticipantHandler {

    /**
     * This method adds the required criteria to handle the StudyParticipantCriteria to the
     * target findings.  It includes the StudyParticipantCriteria to the actual finding criteria
     * (target findings) based on the operator specified.
     * @param studyCrit Any sub types of StudyParticipantCriteria
     * @param opType  The operator used to add this StudyParticipantCriteria  to filter the target findings
     * @param targetFindingType Required type of Finding (which is a sub type of SpecimenBasedMolecularFinding class
     * @param findingCrit Hibernate criteria class that has the required criteria to handle SpecimenBasedFindingSearchCriteria
     *        correponding to  targetFindingType of finding
     * @param session Hibernate session object
     */
   public abstract Collection<? extends SpecimenBasedMolecularFinding>  searchFindings(StudyParticipantCriteria studyCrit, OperatorType opType,  Class targetFindingType, Criteria findingCrit, Session session);

                                      
   public static class SpecimenHandler extends StudyParticipantHandler {
       public Collection<? extends SpecimenBasedMolecularFinding> searchFindings(StudyParticipantCriteria studyCrit, OperatorType opType,  Class targetFindingType, Criteria findingCrit, Session session) {
            Collection<? extends SpecimenBasedMolecularFinding> findings = new ArrayList();
            SpecimenCriteria spCrit = (SpecimenCriteria) studyCrit;
            Collection<String> specimenIDs = spCrit.getSpecimenIDs();



            if (opType == OperatorType.AND)  {
                Criteria specimenCrit = findingCrit.createCriteria("specimen") ;
                specimenCrit.add(Restrictions.in(Specimen.SPECIMEN_ID, specimenIDs));
                findings = findingCrit.list();
            } else {  // means opType =  OperatorType.OR

                 // 1. get findings that only satisfy StudyPartcipant criteria
                 Criteria newFindingCrit = session.createCriteria(targetFindingType);
                 Criteria findingAndSpecimenCrit = newFindingCrit.createCriteria("specimen") ;
                 findingAndSpecimenCrit.add(Restrictions.in(Specimen.SPECIMEN_ID, specimenIDs));
                 List specimenBasedFindings = findingAndSpecimenCrit.list();

                 // 2. now execute FISHFinding itself without Specimen Criteria
                 findings = findingCrit.list();

                 // 3. now combine these two findings
                 findings.addAll(specimenBasedFindings);
            }
            return findings;
       }
   }
   public static class PatientHandler extends StudyParticipantHandler {
         public Collection<? extends SpecimenBasedMolecularFinding>  searchFindings(StudyParticipantCriteria studyCrit, OperatorType opType, Class targetFindingType, Criteria findingCrit, Session session) {
               PatientCriteria patientCrit = (PatientCriteria) studyCrit;

             // convert this patientCrit in to SpecimenCriteria

             Collection<String> studySubjectIdentifiers = patientCrit.getStudySubjectIdentifiers();

             Collection<StudyParticipant> spList = new ArrayList<StudyParticipant>();
             for (Iterator<String> iterator = studySubjectIdentifiers.iterator(); iterator.hasNext();) {
               String s = iterator.next();
               StudyParticipant sp = new StudyParticipant();
               sp.setStudyPartcipantIdentifier(s);
               spList.add(sp);
               /*Specimen spmn = new Specimen();
                   spmn.setStudyParticipant(sp);
                   specimenList.add(spmn);*/
              }

              Query hibQuery = session.createQuery("SELECT  distinct s.specimenID FROM Specimen s WHERE s.studyParticipant IN (:spList) ");
              hibQuery.setParameterList("spList", spList);
              List specimenIDs = hibQuery.list();

              SpecimenCriteria sc = new SpecimenCriteria();
              sc.setSpecimenIDs(specimenIDs);

              SpecimenHandler sh = new SpecimenHandler();
              return sh.searchFindings(sc, opType, targetFindingType, findingCrit, session);
        }
   }

}
