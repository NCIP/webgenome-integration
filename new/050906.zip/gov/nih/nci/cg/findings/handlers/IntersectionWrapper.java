package gov.nih.nci.cg.findings.handlers;

import java.util.Set;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;

/**
 * User: Ram Bhattaru <BR>
 * Date: Apr 20, 2006 <BR>
 * Version: 1.0 <BR>
 */
public class IntersectionWrapper {
    Object object;  // this Object should overridw default equals() & hashCode() methods
    boolean presentInCollection1 = true;
    boolean presentInCollection2 = true;
    boolean presentInCollection3 = true;
    boolean presentInCollection4 = true;
    boolean presentInCollection5 = true;

    public IntersectionWrapper(Object object) {
        this.object = object;
    }

    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        final IntersectionWrapper that = (IntersectionWrapper) o;

        if (object != null ? !object.equals(that.object) : that.object != null) return false;

        return true;
    }

    public int hashCode() {
        return (object != null ? object.hashCode() : 0);
    }

    public static Set<IntersectionWrapper> getCommonObjects(Collection<IntersectionWrapper> collection1,
                                                           Collection<IntersectionWrapper> collection2, Collection<IntersectionWrapper> collection3,
                                                           Collection<IntersectionWrapper> collection4, Collection<IntersectionWrapper> collection5) {

        Collection keyCollection = null;
        if (collection1 != null && collection1.size() > 0) keyCollection = collection1;
        else if (collection2 != null && collection2.size() > 0) keyCollection = collection2;
        else if (collection3 != null && collection3.size() > 0) keyCollection = collection3;
        else if (collection4 != null && collection4.size() > 0) keyCollection = collection4;
        else if (collection5 != null && collection5.size() > 0) keyCollection = collection4;
        else return new HashSet<IntersectionWrapper>(); // nothing in common Hence return empty collection

        Set<IntersectionWrapper> resultSet = new HashSet<IntersectionWrapper>();
        if (keyCollection != null) {
           for (Iterator<IntersectionWrapper> iterator = keyCollection.iterator(); iterator.hasNext();) {
               IntersectionWrapper obj =  iterator.next();
               if (collection1 != null) {
                   if (! collection1.contains(obj)) obj.presentInCollection1 = false;
               }
               if (collection2 != null) {
                   if (! collection2.contains(obj)) obj.presentInCollection2 = false;
               }
               if (collection3 != null) {
                   if (! collection3.contains(obj)) obj.presentInCollection3 = false;
               }
               if (collection4 != null) {
                   if (! collection4.contains(obj)) obj.presentInCollection4 = false;
               }
               if (collection5 != null) {
                   if (! collection5.contains(obj)) obj.presentInCollection5 = false;
               }

               if (obj.presentInCollection1 && obj.presentInCollection2 && obj.presentInCollection3 &&
                   obj.presentInCollection4 && obj.presentInCollection5) {
                   // add to resultSet
                   resultSet.add(obj);
               }

           }
        }
     return resultSet;
    }
}
